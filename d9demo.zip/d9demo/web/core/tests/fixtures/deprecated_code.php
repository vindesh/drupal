<?php
// @phpcs:ignoreFile

/**
 * This class triggers an E_DEPRECATED notice.
 *
 * @see
 */
class PhpDeprecation implements \IteratorAggregate {

  /**
   * {@inheritdoc}
   */
  public function getIterator() {
  }

}
